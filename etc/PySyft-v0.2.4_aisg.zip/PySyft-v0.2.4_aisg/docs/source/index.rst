.. PySyft documentation master file, created by
   sphinx-quickstart on Tue Feb  4 19:04:56 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PySyft's documentation!
==================================

.. toctree::
   :maxdepth: 6
   :caption: Contents:

   api/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
