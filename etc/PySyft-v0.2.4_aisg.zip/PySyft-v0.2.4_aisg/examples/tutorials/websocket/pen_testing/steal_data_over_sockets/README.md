# Steal Data Over Sockets

In this pen testing challenge, you will launch three workers on your local machine which each contain a single tensor. Your mission, should you choose to accept it, is to try to get access to the values within this tensor by any means necessary. 

To begin, run the following script which will start 3 workers and load each worker with a private tensor.
```
$ python start_websocket_servers.py
```

Then you may open the *Challenge Setup* notebook and begin your hacking!