## Deploy PySyft Workers using Docker

Here you will find an example docker-compose file that can deploy three workers alice, bob and charlie using port 8777, 8778, 8779 respectively.

Please follow along with [this short notebook](./deploy-and-connect.ipynb) explaining how to deploy and connect to those workers.
