from syft.serde.protobuf import proto
from syft.serde.protobuf import serde
from syft.serde.protobuf import native_serde
from syft.serde.protobuf import torch_serde

from syft.serde.protobuf.serde import serialize
from syft.serde.protobuf.serde import deserialize
