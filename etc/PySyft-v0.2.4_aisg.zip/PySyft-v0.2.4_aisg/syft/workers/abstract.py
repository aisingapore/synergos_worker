from abc import ABC


class AbstractWorker(ABC):
    pass
