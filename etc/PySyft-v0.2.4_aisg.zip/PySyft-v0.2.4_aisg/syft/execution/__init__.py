from syft.execution.plan import func2plan
from syft.execution.plan import method2plan
from syft.execution.plan import Plan
