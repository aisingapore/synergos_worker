Syft Keras -- EXPERIMENTAL
===================
This is a wrapper around the Keras interface to [TF Encrypted](https://github.com/tf-encrypted/tf-encrypted).
It is experimental and very much in flux, although nearly all of the API will be taken from Keras, which is quite stable.

We currently only reproduce a small subset of the Keras layers.
More will be added in the coming days.
Training is not yet supported, but reserves a high priority on our roadmap.
