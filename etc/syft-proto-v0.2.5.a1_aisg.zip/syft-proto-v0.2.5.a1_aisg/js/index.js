'use strict';
const proto_info = require('../proto.json');
exports.proto_info = proto_info;

const root = require('./protobuf');
exports.protobuf = root;
